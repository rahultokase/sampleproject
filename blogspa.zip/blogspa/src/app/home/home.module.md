## This is Home Page
## Responsibility
1) Acting as a smart container to get all the blogs
2) Cateogrize the blogs into Past and Recent One.
3) Use the dump component to display the Past and Recent Blogs.
