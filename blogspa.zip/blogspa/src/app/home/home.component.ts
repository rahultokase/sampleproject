import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { BlogsService } from '../blogs/blogs.service';
import { Blog } from '../blogs/models/blog';
import { AppAlertService } from '../app-shared/services/app-alert.services';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, OnDestroy {

  loading = true;
  destroyed$ = new Subject();
  blogs: Blog[];
  recentBlogs: Blog[];
  pastBlogs: Blog[];


  constructor(private blogsService: BlogsService, private appAlertService: AppAlertService,
    private router: Router) { }

  ngOnInit(): void {
    this.fetchBlogData();
  }

  /**
   * Fetch the Blog Data.
   */
  fetchBlogData() {
    this.blogsService.readAll().pipe(takeUntil(this.destroyed$),).subscribe(results => {
      this.loading = false;
      this.blogs = results.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      this.populatePastBlogs();
      this.popualteRecentBlogs();
    }, error => {
      this.loading = false;
      this.appAlertService.showErrorMessage(`Error while fetching the blogs data from api. Details:- ${error}`);
    });
  }
  /**
   * Refresh Blog Data.
   */
  refresh() {
    this.loading = true;
    this.fetchBlogData();
  }

  /**
  * Create a Blog.
  */
  createBlog() {
    this.router.navigate(['/blogs/add']);
  }

  /**
   * Populate the Recent Blogs.
   */
  populatePastBlogs() {
    this.pastBlogs = [... this.blogs];
    this.pastBlogs.splice(0, 3);
  }

  /**
   * Populate the Recent Blogs.
   */
  popualteRecentBlogs() {
    this.recentBlogs = this.blogs.slice(0, 3);
  }

  /**
   * Delete All Blogs
   */
  deleteAllBlogs() {
    this.blogsService.deleteAll().subscribe( ()=> {
      this.appAlertService.showMessage("All Blogs Deleted Successfully !!!");
      this.refresh();
    }, error => this.appAlertService.showErrorMessage( `Error while deleting all blogs ${error}`));
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }
}
