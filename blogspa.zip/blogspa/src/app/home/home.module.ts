import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { SharedModule } from '../shared/shared.module';
import { ClarityModule } from '@clr/angular';
import { HomePastPostsComponent } from './components/home-past-posts/home-past-posts.component';
import { HomeRecentPostsComponent } from './components/home-recent-posts/home-recent-posts.component';



@NgModule({
  declarations: [
    HomeComponent,
    HomePastPostsComponent,
    HomeRecentPostsComponent
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    SharedModule,
    ClarityModule
  ]
})
export class HomeModule { }
