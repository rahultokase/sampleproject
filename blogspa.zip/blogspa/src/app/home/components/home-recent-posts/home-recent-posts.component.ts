import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { AppAlertService } from 'src/app/app-shared/services/app-alert.services';
import { BlogsService } from 'src/app/blogs/blogs.service';
import { Blog } from 'src/app/blogs/models/blog';


@Component({
  selector: 'app-home-recent-posts',
  templateUrl: './home-recent-posts.component.html',
  styleUrls: ['./home-recent-posts.component.scss']
})
export class HomeRecentPostsComponent implements OnInit {

  @Input()
  recentBlogs: Blog[];

  @Output()
  refresh$: EventEmitter<boolean> = new EventEmitter();

  showDeleteModal = false;
  selectedBlog: Blog;


  constructor(private router: Router, private blogsService: BlogsService, private appAlertService: AppAlertService) { }

  ngOnInit(): void {
  }

  /**
   * Handling the Edit action.
   * @param blog
   */
  editButtonClick(blog: Blog) {
    this.router.navigate(['/blogs/edit', blog.id]);
  }

  /**
   * Handling the Delete Action.
   * @param blog
   */
  deleteButtonClick(blog: Blog) {
    this.showDeleteModal = true;
    this.selectedBlog = blog;
  }

  /**
  * Perform deletion of Blog.
  */
  deleteBlogConfirm() {
    this.showDeleteModal = false;
    this.blogsService.delete(this.selectedBlog.id).subscribe(response => {
      this.selectedBlog = null;
      this.refresh$.next(true);
      this.appAlertService.showMessage("Blog Deleted Successfully");
    }, error => {
      this.appAlertService.showErrorMessage(`Error while deleting a blog. Details - ${error}`);
    });
  }

}
