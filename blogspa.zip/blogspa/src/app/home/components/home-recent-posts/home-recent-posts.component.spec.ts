import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeRecentPostsComponent } from './home-recent-posts.component';

describe('HomeRecentPostsComponent', () => {
  let component: HomeRecentPostsComponent;
  let fixture: ComponentFixture<HomeRecentPostsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HomeRecentPostsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeRecentPostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
