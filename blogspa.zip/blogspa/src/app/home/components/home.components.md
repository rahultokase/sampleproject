## Define the dump component for displaying the Past and Recent POST.
