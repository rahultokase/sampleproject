import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Blog } from 'src/app/blogs/models/blog';

@Component({
  selector: 'app-home-past-posts',
  templateUrl: './home-past-posts.component.html',
  styleUrls: ['./home-past-posts.component.scss']
})
export class HomePastPostsComponent implements OnInit {

  @Input()
  pastBlogs: Blog[]

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

}
