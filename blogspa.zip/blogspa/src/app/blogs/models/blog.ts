export interface Blog {
  id : number,
  title: string,
  text : string,
  timestamp ?: Date | string
}
