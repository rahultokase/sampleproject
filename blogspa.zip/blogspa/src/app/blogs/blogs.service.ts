import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { BlogsModule } from './blogs.module';
import { Blog } from './models/blog';

const baseURL = 'https://salesforce-blogs.herokuapp.com/blogs/api';

@Injectable({
  providedIn: 'root'
})
export class BlogsService {

  constructor(
    private httpClient: HttpClient
  ) { }

  /**
   * Read All Blogs
   * @returns
   */
  readAll(): Observable<Blog []> {
    return this.httpClient.get(baseURL).pipe(map(response => <Blog []> response));
  }

  /**
   * Read Blog
   * @returns
   */
  read(id): Observable<Blog> {
    return this.httpClient.get(`${baseURL}/${id}`).pipe(map(response => <Blog> response));
  }

  /**
   * Create A Blog
   * @param data
   * @returns
   */
  create(data): Observable<Blog> {
    return this.httpClient.post(baseURL, data).pipe(map(response => <Blog> response));
  }

  /**
   * Update a Blog
   * @param id
   * @param data
   * @returns
   */
  update(id, data): Observable<Blog> {
    return this.httpClient.post(`${baseURL}/${id}`, data).pipe(map(response => <Blog> response));
  }

  /**
   * Delete a Blog
   * @param id
   * @returns
   */
  delete(id): Observable<any> {
    return this.httpClient.delete(`${baseURL}/${id}`).pipe(map(response => <any>response));
  }

  /**
   * Delete All Blogs
   * @returns
   */
  deleteAll(): Observable<any> {
    return this.httpClient.delete(baseURL).pipe(map(response => <any>response));
  }

}
