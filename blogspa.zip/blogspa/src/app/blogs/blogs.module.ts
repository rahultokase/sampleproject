import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BlogsComponent } from './components/blogs/blogs.component';
import { BlogsRoutingModule } from './blogs-routing.module';
import { SharedModule } from '../shared/shared.module';
import { AddEditBlogComponent } from './components/add-edit-blog/add-edit-blog.component';
import { ClarityModule, ClrFormsModule } from '@clr/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    BlogsComponent,
    AddEditBlogComponent
  ],
  imports: [
    CommonModule,
    BlogsRoutingModule,
    SharedModule,
    ClarityModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class BlogsModule { }
