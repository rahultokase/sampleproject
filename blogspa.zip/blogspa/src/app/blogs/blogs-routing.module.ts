import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddEditBlogComponent } from './components/add-edit-blog/add-edit-blog.component';
import { BlogsComponent } from './components/blogs/blogs.component';


const routes: Routes = [
  {
    path: '',
    component: BlogsComponent
  },
  {
    path: 'add',
    component: AddEditBlogComponent
  },
  {
    path: 'edit/:id',
    component: AddEditBlogComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BlogsRoutingModule { }
