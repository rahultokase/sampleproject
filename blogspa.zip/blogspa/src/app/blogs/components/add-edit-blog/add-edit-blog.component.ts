import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ClrForm } from '@clr/angular';
import { first } from 'rxjs/operators';
import { AppAlertService } from 'src/app/app-shared/services/app-alert.services';
import { BlogsService } from '../../blogs.service';

@Component({
  selector: 'app-add-edit-blog',
  templateUrl: './add-edit-blog.component.html',
  styleUrls: ['./add-edit-blog.component.scss']
})
export class AddEditBlogComponent implements OnInit {

  id: string;
  isAddMode: boolean;
  loading = false;
  submitted = false;
  blogForm: FormGroup = new FormGroup({
    title: new FormControl('', Validators.required),
    text: new FormControl('')
  });

  @ViewChild(ClrForm, { static: true }) clrForm;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private blogsService: BlogsService,
    private appAlertService: AppAlertService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.isAddMode = !this.id;
    if (!this.isAddMode) {
      this.blogsService.read(this.id)
        .pipe(first())
        .subscribe(blog => this.blogForm.patchValue(blog),
          error => console.log(`error while rtreiving the blog with id ${this.id} with ${error}`));
    }
  }

  onSubmit() {
    // stop here if form is invalid
    if (this.blogForm.invalid) {
      this.clrForm.markAsTouched();
      return;
    }
    this.loading = true;
    if (!this.submitted) {
      this.submitted = true;
      this.isAddMode ? this.createBlog() : this.updateBlog();
    }
  }

  /**
   * Creating a Blog.
   */
  private createBlog() {
    this.blogsService.create(this.blogForm.value)
      .pipe(first())
      .subscribe({
        next: () => {
          this.appAlertService.showMessage(`A Blog is created sucessfully !!!`);
          this.router.navigate(['/home'], { relativeTo: this.route });
        },
        error: error => {
          this.loading = false;
          this.appAlertService.showErrorMessage(`Error while creating a Blog Details:- ${error}`);
        }
      });
  }

  /**
   * Creating a Blog.
   */
  private updateBlog() {
    this.blogsService.update(this.id, this.blogForm.value)
      .pipe(first())
      .subscribe({
        next: () => {
          this.appAlertService.showMessage(`A Blog ${this.id} updated successfully !!!`);
          this.router.navigate(['/home'], { relativeTo: this.route });
        },
        error: error => {
          this.loading = false;
          this.appAlertService.showErrorMessage(`Error while updating a blog. Details:- ${error}`);
        }
      });
  }
}
