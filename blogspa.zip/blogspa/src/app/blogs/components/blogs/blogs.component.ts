import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { catchError, takeUntil } from 'rxjs/operators';
import { BlogsService } from '../../blogs.service';
import { Blog } from '../../models/blog';

@Component({
  selector: 'app-blogs',
  templateUrl: './blogs.component.html',
  styleUrls: ['./blogs.component.scss']
})
export class BlogsComponent implements OnInit, OnDestroy {

  constructor(private blogsService: BlogsService) { }
  loading = true;
  destroyed$ = new Subject();
  blogs: Blog[];


  ngOnInit(): void {
    this.blogsService.readAll().pipe(takeUntil(this.destroyed$)).subscribe(results => {
      this.loading = false;
      this.blogs = results;
    }, error => {
      this.loading = false;

    });
  }

  ngOnDestroy() {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

}
