import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Blog } from 'src/app/blogs/models/blog';

/**
 * Component to Display a blog.
 */
@Component({
  selector: 'app-blog-card',
  templateUrl: './blog-card.component.html',
  styleUrls: ['./blog-card.component.scss']
})
export class BlogCardComponent implements OnInit {

  @Input()
  blog: Blog;

  @Output()
  editBlog$: EventEmitter<Blog> = new EventEmitter();

  @Output()
  deleteBlog$: EventEmitter<Blog> = new EventEmitter();


  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  /**
   * Emitting the Edit button event.
   */
  editButtonClick() {
    this.editBlog$.next(this.blog);
  }

  /**
   * Emitting the Delete Button Event.
   */
  deleteButtonClick() {
    this.deleteBlog$.next(this.blog);
  }

}
