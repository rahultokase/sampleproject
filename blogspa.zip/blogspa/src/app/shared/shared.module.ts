import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BlogListComponent } from './components/blog-list/blog-list.component';
import { BlogCardComponent } from './components/blog-card/blog-card.component';
import { ClarityModule } from '@clr/angular';
import { ProgressComponent } from './components/progress/progress.component';
import { AppSharedModule } from '../app-shared/app-shared.module';



@NgModule({
  declarations: [
    BlogListComponent,
    BlogCardComponent,
    ProgressComponent,
  ],
  imports: [
    CommonModule,
    ClarityModule,
    AppSharedModule
  ],
  exports:[
    BlogListComponent,
    BlogCardComponent,
    ProgressComponent
  ]
})
export class SharedModule { }
