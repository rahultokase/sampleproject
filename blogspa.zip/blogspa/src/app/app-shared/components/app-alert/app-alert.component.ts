import { Component } from '@angular/core';
import { AppAlertService } from 'src/app/app-shared/services/app-alert.services';

@Component({
  selector: 'app-app-alert',
  templateUrl: './app-alert.component.html',
  styleUrls: ['./app-alert.component.scss']
})
export class AppAlertComponent {

  constructor(public appAlertService: AppAlertService) {}

  onClose(value: any): void {
    this.appAlertService.onClose(value);
  }

}
