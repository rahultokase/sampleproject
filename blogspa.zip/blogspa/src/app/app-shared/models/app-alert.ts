export enum AppAlertType {
  INFO = "info",
  WARNING = "warning",
  SUCCESS = "success",
  DANGER = "danger"
}

export interface AppAlertConfig {
  clrAlertType?: AppAlertType,
  message: string;
  clrAlertAppLevel?: boolean;
  clrAlertClosable?: boolean;
}
