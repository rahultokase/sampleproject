import { Injectable, } from '@angular/core';
import { Subject } from 'rxjs';
import { AppAlertConfig, AppAlertType } from '../models/app-alert';


@Injectable({
  providedIn: 'root'
})
export class AppAlertService {
  shouldShowAlert: boolean = false;
  public alertConfig: AppAlertConfig = {
    message:'',
    clrAlertAppLevel: true,
    clrAlertClosable: true
  }
  close = new Subject<any>();

  constructor() { }

  /**
   * show Alerts
   * @param config
   * @returns
   */
  show(config: AppAlertConfig): AppAlertService {
    this.shouldShowAlert = true;
    this.alertConfig = { ...this.alertConfig, ...config };
    return this;
  }

  showMessage(message: string) :  AppAlertService {
    this.shouldShowAlert = true;
    let config = {message : message};
    this.alertConfig = { ...this.alertConfig, ...config };
    return this;
  }

  showErrorMessage(message: string) :  AppAlertService {
    this.shouldShowAlert = true;
    let config = {message : message, clrAlertType: AppAlertType.DANGER};
    this.alertConfig = { ...this.alertConfig, ...config };
    return this;
  }
  /**
   * Hide Alerts
   * @returns
   */
  hide(): AppAlertService {
    this.shouldShowAlert = false;
    return this;
  }

  /**
   * Toggle Alerts
   * @returns
   */
  toggle(): AppAlertService {
    this.shouldShowAlert = !this.shouldShowAlert;
    return this;
  }

  /**
   * Close Alerts
   * @param value
   */
  onClose(value: any): any {
    this.hide();
    this.close.next(value);
  }

  /**
   * On Close.
   * @returns
   */
  onClose$(): any {
    return this.close;
  }
}
