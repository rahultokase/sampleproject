import { NgModule } from '@angular/core';
import { ClarityModule } from '@clr/angular';
import { AppAlertComponent } from './components/app-alert/app-alert.component';
import { CommonModule } from '@angular/common';


@NgModule({
  declarations: [
    AppAlertComponent
  ],
  imports: [
    CommonModule,
    ClarityModule
  ],
  exports: [AppAlertComponent]
})
export class AppSharedModule { }
