## Define the components use at both application and Individual Feature module
This module makes sure that Feature Shared modules always loaded lazily.
