## Handling the all the application level errors.
